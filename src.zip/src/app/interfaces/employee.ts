export interface Employee {
    'name':string;
    'email':string;
    'phone':string;
    'department':string;
}
