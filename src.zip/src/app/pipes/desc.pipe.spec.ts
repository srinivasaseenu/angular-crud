import { DescPipe } from './desc.pipe';

describe('DescPipe', () => {
  it('create an instance', () => {
    const pipe = new DescPipe();
    expect(pipe).toBeTruthy();
  });
});
