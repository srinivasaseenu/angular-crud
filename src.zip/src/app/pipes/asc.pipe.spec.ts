import { AscPipe } from './asc.pipe';

describe('AscPipe', () => {
  it('create an instance', () => {
    const pipe = new AscPipe();
    expect(pipe).toBeTruthy();
  });
});
